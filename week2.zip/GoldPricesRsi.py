import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt

# دانلود داده‌های طلا
gold = yf.download("GC=F", start="2024-01-01", end="2025-07-27")

# فقط قیمت پایانی رو نگه می‌داریم
df = gold[['Close']].copy()

# محاسبه RSI
def calculate_rsi(data, period=14):
    delta = data['Close'].diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

df['RSI'] = calculate_rsi(df)

# خروجی
print(df.tail(10))

# رسم نمودار
df[['Close', 'RSI']].plot(subplots=True, figsize=(10, 6), title=['Gold Price', 'RSI'])
plt.tight_layout()
plt.show()