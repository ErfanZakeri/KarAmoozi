import sqlite3
import re

# --- تنظیمات ---
input_file = "FemliData.txt"  # اسم فایل خروجی‌ای که ذخیره کردی
db_file = "FemliData.db"     # اسم دیتابیس SQLite

# --- اتصال به دیتابیس و ساخت جدول ---
conn = sqlite3.connect(db_file)
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS market_data (
        time TEXT,
        last_price REAL,
        volume REAL,
        trades INTEGER
    )
''')
conn.commit()

# --- خواندن فایل ---
with open(input_file, "r", encoding="utf-8") as f:
    lines = f.readlines()

# --- استخراج داده از هر خط و ذخیره در دیتابیس ---
pattern = re.compile(
    r"\[(.*?)\] Last Price: ([\d.]+) \| Volume: ([\d.]+) \| Trades: ([\d.]+)"
)

for line in lines:
    match = pattern.search(line)
    if match:
        time_str = match.group(1)
        last_price = float(match.group(2))
        volume = float(match.group(3))
        trades = int(float(match.group(4)))  # ممکنه اعشار داشته باشه
        
        cursor.execute('''
            INSERT INTO market_data (time, last_price, volume, trades)
            VALUES (?, ?, ?, ?)
        ''', (time_str, last_price, volume, trades))

conn.commit()
conn.close()

print(" Data imported to database successfully.")
