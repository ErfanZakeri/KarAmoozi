import sqlite3
import re

# اتصال به دیتابیس
conn = sqlite3.connect("FemliData.db")
cursor = conn.cursor()

# باز کردن فایل متنی
with open("FemliData.txt", "r", encoding="utf-8") as f:
    for line in f:
        match = re.match(r'\[(.*?)\] Last Price: (\d+\.\d+) \| Volume: ([\d.]+) \| Trades: (\d+)', line)
        if match:
            time_str = match.group(1)
            last_price = float(match.group(2))
            volume = float(match.group(3))
            trades = int(match.group(4))

            # درج در دیتابیس
            cursor.execute("""
                INSERT INTO market_data (time, last_price, volume, trades)
                VALUES (?, ?, ?, ?)
            """, (time_str, last_price, volume, trades))

conn.commit()
conn.close()
print("[INFO] All data inserted successfully.")
